// FIREBASE CONFIG
const firebaseConfig = {
    apiKey: "AIzaSyA8NpjKfRUjcqZirXG6K0khjTbd_FwKLSM",
    authDomain: "prj-anim-p-appintegra.firebaseapp.com",
    databaseURL: "https://prj-anim-p-appintegra-default-rtdb.firebaseio.com",
    projectId: "prj-anim-p-appintegra",
    storageBucket: "prj-anim-p-appintegra.appspot.com",
    messagingSenderId: "123219769717",
    appId: "1:123219769717:web:15a6c86f7ca661e89f7b3c"
};
export default firebaseConfig
