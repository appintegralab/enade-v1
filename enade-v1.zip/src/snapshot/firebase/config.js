// FIREBASE CONFIG
const firebaseConfig = {
    apiKey: "AIzaSyC9Nc9jKj_ZEFvjOt-JONoWeM_KYMaooQE",
  authDomain: "prj-enade-prd.firebaseapp.com",
  databaseURL: "https://prj-enade-prd-default-rtdb.firebaseio.com",
  projectId: "prj-enade-prd",
  storageBucket: "prj-enade-prd.appspot.com",
  messagingSenderId: "857281947455",
  appId: "1:857281947455:web:f6edffe2b7323bf6c0558a"
};
export default firebaseConfig
