export default {
    "assessor": {
        cargo: "Assessor (a) de Área"
    },
    "coord-area": {
        cargo: "Coordenador (a) de Grande Área"
    },
    "coord-regional": {
        cargo: "Coordenador (a) Regional"
    },
    "diretor-micro": {
        cargo: "Diretor (a) de Microrregião"
    },
    "gestor-area": {
        cargo: "Gestor (a) de Grande Área"
    },
    "profHor": {
        cargo: "Professor(a) Horista"
    },
    "profTI": {
        cargo: "Professor(a) TI"
    },
    "profTP": {
        cargo: "Professor(a) TP"
    },
    "vpa": {
        cargo: "VPA - Outros"
    },
    "outro": {
        cargo: "Outro"
    }
}