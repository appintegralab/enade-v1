export default {
    "GO": {
        regional: "Goiás"
    },
    "NO": {
        regional: "Nordeste"
    },
    "MG": {
        regional: "Minas Gerais"
    },
    "RJ": {
        regional: "Rio de Janeiro"
    },
    "SP": {
        regional: "São Paulo"
    },
    "SUL": {
        regional: "Sul"
    }
}