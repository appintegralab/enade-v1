<template>
    <span>
        <span>versão</span>
        <span class="rounded border ml-1 px-1 finter text-[8pt] fw-500 border-white">
            22.07.12.12.52
        </span>
    </span>
</template>
<script>
export default {

}
</script>
<style lang="">
    
</style>